CREATE TABLE BBS(
	bbsTitle VARCHAR(20),
	bbsID VARCHAR(20),
	bbsDate DATETIME,
	bbsContent VARCHAR(2048),
	PRIMARY KEY (bbsID)
);